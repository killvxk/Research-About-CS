
#ifndef HASHES_H
#define HASHES_H

//! Precalculated DJB2 Hashes.
#define H_KERNEL32           0x6ddb9555
#define H_NTDLL              0x1edab0ed

#endif // END HASHES_H
