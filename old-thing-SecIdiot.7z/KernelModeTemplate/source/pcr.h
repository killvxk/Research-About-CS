
#ifndef PCR_H
#define PCR_H

PVOID PcrNtPointer( VOID );

PVOID PcrGetModule( IN ULONG Hsh );

#endif
