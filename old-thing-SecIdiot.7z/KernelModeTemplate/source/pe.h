
#ifndef PE_H
#define PE_H

PVOID PeGetFuncEat( IN PVOID Ptr, IN ULONG Hsh );

#endif // END PE_H
