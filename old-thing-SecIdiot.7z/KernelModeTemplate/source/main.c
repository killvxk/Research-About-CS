
#include "common.h"

KMFUNC void KmEntryPoint( VOID )
{

};
