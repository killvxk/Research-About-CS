
#ifndef HASH_H
#define HASH_H

ULONG HashString( IN PVOID Inp, IN ULONG Len );

#endif // END HASH_H
