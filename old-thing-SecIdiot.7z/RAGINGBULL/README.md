# About

RAGINGBULL is a DoublePulsar SMB2 variant for CVE-2020-0796. Intended to be run on Microsoft Windows 1909 installations. In its current state, its nothing more than a project template that will be developed during an active stream. Unfortunately, as of late I have yet to decide on the date of this stream.

## Tools
* Assembly: nasm
* Compiler: mingw-w64
* Python: python3
* Pip: pefile
