
#ifndef HASH_H
#define HASH_H

SHARED ULONG HashString( IN PVOID Inp, IN ULONG Len );

#endif // END HASH_H
