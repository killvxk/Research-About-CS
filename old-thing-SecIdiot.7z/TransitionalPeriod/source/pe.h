
#ifndef PE_H
#define PE_H

SHARED PVOID PeGetFuncEat( IN PVOID Ptr, IN ULONG Hsh );

#endif // END PE_H
