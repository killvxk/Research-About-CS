
#ifndef PEB_H
#define PEB_H

UMFUNC PVOID PebGetModule( IN ULONG Hsh );

#endif // END PEB_H
